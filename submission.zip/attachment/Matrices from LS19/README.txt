"results" contains all the results.
  -- In "results", 148-172 represent the Hamming weight.
  -- In each folder, "matrix" contains the circuits, "result" contains the running file, and "target" contains the target file generated in [LS19].
  -- Because some files are too large, we have to put them on GitHub: https://github.com/NoUsersforSub/SUBMISSION.
  
"check.py" is used to check all the results. We can put it into each folder to run it. We provide an example in "results/148".