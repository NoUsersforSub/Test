import os
import re

path = 'result'
files = os.listdir(path)

oldresultdict = dict()
newresultdict = dict()

# 读取老结果
with open('origialresult.txt', 'r') as f:
    while True:
        line = f.readline().replace('\n', '')
        if line == '':
            break
        nums = re.findall('\d+', line)
        oldresultdict[nums[0]] = nums[1]

for file in files:
    num = re.findall('\d+', file)
    mincost = 10000
    with open('{}/{}'.format(path, file), 'r') as f:
        lines = f.readlines()
        for line in lines:
            if 'Cost' in line:
                thisnum = re.findall('Cost:\d+', line)
                cost = int(thisnum[0][5:])
                if cost < mincost:
                    mincost = cost
    newresultdict[str(num[0])] = str(mincost)

BadNumList = []
goodnum = 0
badnum = 0
for key in oldresultdict.keys():
    oldres = int(oldresultdict[key])
    newres = int(newresultdict[key])
    if newres >= oldres:
        BadNumList.append(key)
        badnum += 1
    else:
        goodnum += 1

print("final num: {}".format(goodnum + badnum))
print("good  num: {}".format(goodnum))
print("bad   num: {}".format(badnum))
print('')
print("all bad num are shown as follows.")
print(BadNumList)
print('')

# 找优化最多的XOR
MAXnum = 0
xuhao = -1
allnum = []
allxuhao = []
for key in oldresultdict.keys():
    oldres = int(oldresultdict[key])
    newres = int(newresultdict[key])
    allnum.append(oldres - newres)
    allxuhao.append(int(key))
    if oldres - newres > MAXnum:
        MAXnum = oldres - newres
        xuhao = int(key)
print("best opt: {}".format(MAXnum))
print("site   : {}".format(xuhao))
print('')
print("all opt/site:")
print(allnum)
print(allxuhao)
print('')


MINXOR = 10000
xuhao = -1
allXOR = []
allxuhao = []
for key in oldresultdict.keys():
    oldres = int(oldresultdict[key])
    newres = int(newresultdict[key])
    allXOR.append(newres)
    allxuhao.append(int(key))
    if newres < MINXOR:
        MINXOR = newres
        xuhao = int(key)
print("min XOR: {}".format(MINXOR))
print("site   : {}".format(xuhao))

print("all XOR/site")
print(allXOR)
print(allxuhao)