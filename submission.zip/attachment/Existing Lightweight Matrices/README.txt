In this folder, we provide the new results and the source code to check them.

"New Results" contains all the optimized results.

"Matrices" contains the corresponding matrices.

"Check" contains the source code to check them.
	-- The matrix is put into "matrix.txt".
	-- The circuit is put into "listold.txt".
	-- We can run "CHECK.py" to check the results.
	-- Our code can provide the correctness, the depth, and the outputs.