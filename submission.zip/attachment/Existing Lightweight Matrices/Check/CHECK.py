
from extend_graph import *


NumberBase = 0
with open("matrix.txt", 'r') as f:
    line = f.readline().replace('\n', '')
    NumberBase = len(line)


targetdict = dict()
newNodeHamming = dict()
# for key in graph.outputdict.keys():
#     thislist = copy.deepcopy(list(graph.HammingSet[str(graph.outputdict[key])]))
#     thislist.sort()
#     targetdict[str(graph.outputdict[key])] = thislist




def getHamming(onelist, HammingSet):
    NewHamming = []
    for onenode in onelist:
        thisHamming = HammingSet[onenode]
        for oneHam in thisHamming:
            if oneHam in NewHamming:
                NewHamming.remove(oneHam)
            elif oneHam not in NewHamming:
                NewHamming.append(oneHam)
    return NewHamming


with open("listold.txt", 'r') as f:
    with open("listnew.txt", 'w') as g:
        nodedict = dict()
        NonBaseNode = []
        while True:
            line = f.readline().replace("\n", '')
            if line == '':
                break
            numberall = re.findall(r"\d+\.?\d*", line)
            targetnode = numberall[0]
            NonBaseNode.append(targetnode)
            leftnodelist = []
            for i in range(1, 3):
                leftnodelist.append(numberall[i])
            nodedict[targetnode] = leftnodelist

        Hammingweight = dict()
        for i in range(NumberBase):
            Hammingweight[str(i)] = []
            Hammingweight[str(i)].append(str(i))

        while len(NonBaseNode) > 0:
            for node in NonBaseNode:
                BaseSize = len(nodedict[node])
                thissymbol = 1
                for eachnode in nodedict[node]:
                    if eachnode not in Hammingweight.keys():
                        thissymbol = 0
                        break
                if thissymbol == 0:
                    continue

                NewHam = getHamming(nodedict[node], Hammingweight)
                Hammingweight[node] = copy.deepcopy(NewHam)
                NonBaseNode.remove(node)
                break

        for key in Hammingweight.keys():
            g.write("{}: {}\n".format(key, Hammingweight[key]))


with open("listnew.txt", 'r') as f:
    while True:
        line = f.readline().replace('\n', '')
        if line == '':
            break
        nodelist = re.findall(r"\d+\.?\d*", line)
        targetnode = nodelist[0]
        leftnodelist = []
        for i in range(1, len(nodelist)):
            leftnodelist.append(nodelist[i])
        leftnodelist.sort()
        newNodeHamming[targetnode] = leftnodelist


for key in newNodeHamming.keys():
    newNodeHamming[key].sort()


matrixHamming = dict()
with open("matrix.txt", 'r') as f:
    linenumber = 0
    while True:
        line = f.readline().replace('\n', '')
        if line == '':
            break
        matrixHamming[str(linenumber)] = []
        for bit in range(len(line)):
            if line[bit] == '1':
                matrixHamming[str(linenumber)].append(str(bit))
        matrixHamming[str(linenumber)].sort()
        linenumber += 1


outputdict = dict()

currectNumber = 0
for i in range(NumberBase):
    print("key: {}".format(i))
    targetHamming = matrixHamming[str(i)]
    print(targetHamming)
    for key in newNodeHamming.keys():
        if newNodeHamming[key] == targetHamming:
            currectNumber += 1
            print(newNodeHamming[key])
            outputdict[str(i)] = key

print("output values:")
print(outputdict)
print("current number = {}".format(currectNumber))
print("NumTarget is   = {}".format(NumberBase))


nodedepth = dict()
for i in range(NumberBase):
    nodedepth[str(i)] = 0
with open("listold.txt", 'r') as f:
    nodedict = dict()
    NonBaseNode = []
    while True:
        line = f.readline().replace("\n", '')
        if line == '':
            break
        numberall = re.findall(r"\d+\.?\d*", line)
        targetnode = numberall[0]
        NonBaseNode.append(targetnode)
        leftnodelist = []
        for i in range(1, 3):
            leftnodelist.append(numberall[i])
        nodedict[targetnode] = leftnodelist

    # Hammingweight = dict()
    # for i in range(NumberBase):
    #     Hammingweight[str(i)] = []
    #     Hammingweight[str(i)].append(str(i))

    nodedepth = dict()
    for i in range(NumberBase):
        nodedepth[str(i)] = 0


    while len(NonBaseNode) > 0:
        for node in NonBaseNode:
            BaseSize = len(nodedict[node])
            thissymbol = 1
            for eachnode in nodedict[node]:
                if eachnode not in nodedepth.keys():
                    thissymbol = 0
                    break
            if thissymbol == 0:
                continue

            targetnode = node
            node1 = nodedict[node][0]
            node2 = nodedict[node][1]
            nodedepth[targetnode] = max(nodedepth[node1] + 1, nodedepth[node2] + 1)
            NonBaseNode.remove(node)

            break

maxdepth = 0
for key in nodedepth.keys():
    if nodedepth[key] > maxdepth:
        maxdepth = nodedepth[key]
print("depth: {}".format(maxdepth))


for key in nodedepth.keys():
    print("value:  {}||| depth: {}".format(key, nodedepth[key]))