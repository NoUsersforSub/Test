The running files are too large to show. We put them on GitHub.

"Algorithm" contains the source code. We can run it as follows.

	-- In "heuristics.py", delete Line 8 or Line 9.
	-- In "heuristics.py" Line 209 and Line 210, choose the number of rows and columns.
	-- In "heuristics.py" Line 292, choose the number of "allMaxNum". The number is the times we need to run.
	-- In "heuristics.py" Line 293, choose the number of "XORnum". When the number of XOR gates is less than "XORnum", the optimized algorithm will be used (default:10000).
	
	-- In "FrameV1Extend.h" Line 22, "PreviousXORnumber" represents the previous number of XOR gates. When we find a better result, we will return it.
	-- In "FrameV1Extend.h" Line 23, "PreviousDEPTH" is the depth limitation.
	-- In "FrameV1Extend.h" Line 27 and Line 28, choose the number of rows and columns.
	
	-- In "matrix.txt", we put the matrix in it.
	
	-- Then, we use "g++ main.cpp -o test -std=c++11" to generate the corresponding file.
	
	-- Final, we run "python3 heuristics.py" and check the results.
	
	-- We provide an example with the matrix "KLSW".