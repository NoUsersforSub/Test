We provide explanations for the results in our submission.



"Algorithm" contains the source code of Algorithm 7.
	In "FrameV1Extend.h" Line 17, we can choose OPTION=2 or OPTION=3 (OPTION=5 is for global optimization).
	In "FrameV1Extend.h" Line 31 and Line 32, we can choose the number of rows and columns.
	In "FrameV1Extend.h" Line 25, we can set the reduced XORs. It holds that New XORs + adiitionalXORnumber + 1 = Previous XORs. For example, the previous XORs for [KLSW] is 92, we set adiitionalXORnumber = 1, new circuit requires 90 XORs (90+1+1=92).
	In "myseq.txt", we put the circuit in it.
	Then, we use "g++ main.cpp -o test -std=c++11" to generate it.
	Next, we can run "./test" to find better results.
	We give an example of the matrix from [KLSW17] with 92 XORs, which can be reduced to 90 XORs within 10 minutes.
	
	

"Existing Lightweight Matrices" contains the results of optimized linear layers of block ciphers. We provide codes to check the results.
	"New Results" contains all the optimized results.
	"Matrices" contains the corresponding matrices.
	"Check" contains the source code to check them.
		-- The matrix is put into "matrix.txt".
		-- The circuit is put into "listold.txt".
		-- We can run "CHECK.py" to check the results.
		-- Our code can provide correctness, depth, and outputs.
	
	

"More MDS Matrices" contains the results of 4254 MDS matrices proposed by Li et al. [LS19].
	"results" contains all the results.
		-- In "results", 148-172 represent the Hamming weight.
		-- In each folder, "matrix" contains the circuits, "result" contains the running file, and "target" contains the target file generated in [LS19].
		-- Because some files are too large, we have to put them on GitHub: https://github.com/NoUsersforSub/SUBMISSION.
	"check.py" is used to check all the results. We can put it into each folder to run it. We provide an example in "results/148".



"Performance in Hardware" contains the results of AES MixColumns using UMC 55 nm.
	In each folder, we provide the report, the output, and the file "AES.v".



"Running Time" contains the results of the running time.
	"Algorithm" contains the source code. We can run it as follows.
		-- In "heuristics.py", delete Line 8 or Line 9.
		-- In "heuristics.py" Line 209 and Line 210, choose the number of rows and columns.
		-- In "heuristics.py" Line 292, choose the number of "allMaxNum". The number is the times we need to run.
		-- In "heuristics.py" Line 293, choose the number of "XORnum". When the number of XOR gates is less than "XORnum", the optimized algorithm will be used (default:10000).
		
		-- In "FrameV1Extend.h" Line 22, "PreviousXORnumber" represents the previous number of XOR gates. When we find a better result, we will return it.
		-- In "FrameV1Extend.h" Line 23, "PreviousDEPTH" is the depth limitation.
		-- In "FrameV1Extend.h" Line 27 and Line 28, choose the number of rows and columns.
		
		-- In "matrix.txt", we put the matrix in it.
		
		-- Then, we use "g++ main.cpp -o test -std=c++11" to generate the corresponding file.
		
		-- Final, we run "python3 heuristics.py" and check the results.
		
		-- We provide an example with the matrix "KLSW".