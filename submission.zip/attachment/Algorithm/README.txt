In "FrameV1Extend.h" Line 17, we can choose OPTION=2 or OPTION=3 (OPTION=5 is for global optimization).
In "FrameV1Extend.h" Line 31 and Line 32, we can choose the number of rows and columns.

In "myseq.txt", we put the circuit in it.

Then, we use "g++ main.cpp -o test -std=c++11" to generate it.

Next, we can run "./test" to find better results.